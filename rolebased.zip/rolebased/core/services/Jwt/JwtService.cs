﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace core.services.Jwt
{
    public class JwtService
    {
        public string SecretKey { get; set; }

        public int TokenDuration { get; set; }

        public readonly IConfiguration config;

        public JwtService(IConfiguration _config)
        {
            config = _config;
            SecretKey = config.GetSection("jwtConfig").GetSection("Key").Value;
            TokenDuration = int.Parse(config.GetSection("jwtConfig").GetSection("Duration").Value);
        }



        public string GenerateToken(string userName,Guid id, IList<string> roles)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(SecretKey));

            var signature = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, userName),
                new Claim(ClaimTypes.NameIdentifier,$"{id}"),
            };

            foreach (var role in roles)
            {
                claims.Add(new Claim(ClaimTypes.Role, role));
            }

            var jwtToken = new JwtSecurityToken(
                issuer: "localhost",
                audience: "localhost",
                claims,
                expires: DateTime.Now.AddMinutes(TokenDuration),
                signingCredentials: signature
                );

            return new JwtSecurityTokenHandler().WriteToken(jwtToken);

        }
    }
}
