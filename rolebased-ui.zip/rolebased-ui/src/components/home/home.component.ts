import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { ActivatedRoute, Router, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent  {
api:any;
role:boolean;
constructor(apiservice:ApiService,private router:Router,private route:ActivatedRoute){
this.api = apiservice
this.role = sessionStorage.getItem("role") == "Admin"? true:false;
}

myInfo(){
this.router.navigate(['/home/myinfo'])
}

allUsers(){
  this.router.navigate(['/home/allusers'])
}

chat(){
  this.router.navigate(['/home/chat'])
}

logout(){
  sessionStorage.clear();
  this.router.navigate(['/login'])
}

}
