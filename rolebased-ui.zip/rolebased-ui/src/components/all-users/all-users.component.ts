import { APP_BOOTSTRAP_LISTENER, Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { formatDate, NgClass } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import * as bootstrap from 'bootstrap';

@Component({
  selector: 'app-all-users',
  standalone: true,
  imports: [NgClass,ReactiveFormsModule],
  templateUrl: './all-users.component.html',
  styleUrl: './all-users.component.css'
})
export class AllUsersComponent implements OnInit {
data:any;
constructor(private api:ApiService){
}

getall(){
  this.api.allusers().subscribe((res)=>{
    this.data = JSON.parse(res);
  })
}

ngOnInit(): void {
    this.getall();
}

formatdate(date:Date){
  return formatDate(date,"dd/MM/yyyy","en");
}

editForm = new FormGroup({
  firstName: new FormControl( ['', [Validators.required]]),
  lastName:new FormControl(['', [Validators.required]]) ,
  // email:new FormControl(['', [Validators.required, Validators.email]]) ,
  gender:new FormControl(['', [Validators.required]]) ,
  dob:new FormControl(['', [Validators.required]]) ,
  role: new FormControl(['', [Validators.required]]),
})

userId:any;
onEdit(item: any): void {
this.userId = item.id;
  this.editForm.patchValue({
    firstName: item.firstName,
    lastName: item.lastName,
    // email: item.email,
    gender: item.gender,
    dob: item.dob ? formatDate(new Date(item.dob), 'yyyy-MM-dd', 'en') : item.dob,
    role: item.role,
  });

  // Open the modal
  const modal = new bootstrap.Modal(document.getElementById('editModal')!);

  modal.show();
}


onUpdate(): void {

  const modalElement = new bootstrap.Modal(document.getElementById('editModal')!);

  const data = {
    ... this.editForm.value
  }
  this.api.updateUser(this.userId,data).subscribe((res)=>{
    if(res=="notFound"){
      alert("an error occured");
    }
    else{
      modalElement.hide();
      alert("user updated");
      this.getall();
    }
  })
  
  
  
}

onDelete(item: any): void {
if(confirm("you really want to delete this user")){
  this.api.deleteUser(item.id).subscribe((res)=>{
    if(res == "unavailable"){
      alert("an error occured");
    }
    else{
      this.getall();
      alert("user inactivated")
    }
  })
}
}

}
